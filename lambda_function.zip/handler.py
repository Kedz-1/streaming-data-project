import boto3
import json
import requests
from datetime import datetime
import logging
import os
from src.main import fetch_and_send_articles

logging.basicConfig(level=logging.INFO)



def handler(event, context):


    try:
       
        print("EVENT:", event)
        search_term = os.environ.get("SEARCH_TERM")
        queue_name = os.environ.get("QUEUE_NAME")
        date_from = os.environ.get("DATE_FROM", None)
        guardian_key = os.environ.get("GUARDIAN_KEY")

        print("search_term:", search_term )
        print("date_from:", date_from)
        print("queue_name:", queue_name)
        print("guardian_key:", guardian_key)

        logging.info(f"Running Lambda with search_term='{search_term}', date_from='{date_from}'")
        
        if not search_term:
            raise ValueError("Event must include a 'search_term'")

        logging.info('Lambda function has run successfully')
        return fetch_and_send_articles(search_term, queue_name, date_from)
        

    except Exception as e:

        logging.error(f'An error has occured when trying to run the lambda function: {e}')
        raise
        
#fetch_and_send_articles([], 'guardian_queue', '2025-01-01')
